<?php
require 'alumno.php';
require 'insertar.php';
require 'actualizar.php';
require 'eliminar.php';
require 'update.php';
require 'conexion.php';

?>